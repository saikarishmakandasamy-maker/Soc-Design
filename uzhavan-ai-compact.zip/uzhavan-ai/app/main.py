"""Offline web server. Serves the UI and a small JSON API on the local network.

  python -m app.main                 # http://<device-ip>:8080
  python -m app.main --analyze leaf.jpg --lang ta --zone Thanjavur   # CLI, no server
"""
import argparse
import json
import logging
import sys
from pathlib import Path

from . import __version__
from .config import load_settings

STATIC = Path(__file__).with_name("static")
log = logging.getLogger("uzhavan")


def create_app(cfg: dict | None = None):
    from fastapi import FastAPI, File, Form, HTTPException, UploadFile
    from fastapi.responses import FileResponse, JSONResponse, Response
    from fastapi.staticfiles import StaticFiles
    from starlette.concurrency import run_in_threadpool

    from .i18n import strings
    from .pipeline import Advisor
    from .speech.stt import build_stt
    from .speech.tts import build_tts

    cfg = cfg or load_settings()
    advisor = Advisor(cfg)
    stt, tts = build_stt(cfg), build_tts(cfg)
    app = FastAPI(title="Uzhavan AI", version=__version__)
    app.state.advisor = advisor

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/status")
    def status():
        return {**advisor.status(), "version": __version__, "stt": stt.name, "tts": tts.name,
                "tts_langs": [l for l in ("en", "hi", "ta") if tts.available(l)]}

    @app.get("/api/meta")
    def meta():
        return {"strings": strings(),
                "crops": {k: v for k, v in advisor.kb.crops.items() if k not in ("multi", "unknown")},
                "zones": {z: i["name"] for z, i in advisor.regions.zones.items()},
                # crops the vision model can recognise, in display order (drives the crop buttons)
                "model_crops": [c for c in ("tomato", "potato", "maize", "chilli", "grape", "rice")
                                if any((advisor.kb.get(l) or {}).get("crop") == c for l in advisor.vision.labels)],
                "districts": advisor.regions.districts(),
                "defaults": cfg.get("defaults", {})}

    @app.post("/api/analyze")
    async def analyze(image: UploadFile = File(...), lang: str = Form("en"), zone: str = Form(""),
                      crop: str = Form(""), severity: str = Form(""), label: str = Form("")):
        data = await image.read()
        if not data:
            raise HTTPException(400, "empty image")
        if len(data) > 15 * 1024 * 1024:
            raise HTTPException(413, "image too large")
        try:
            # Heavy work runs in a worker thread so the server keeps answering other requests.
            # With Llama loaded, the card comes back at once and the UI calls /api/explain.
            return await run_in_threadpool(advisor.analyze, data, lang, zone or None, crop or None,
                                           severity or None, image.filename, not advisor.llm.available(),
                                           label or None)
        except Exception as e:
            log.exception("analyze failed")
            raise HTTPException(422, f"could not process image: {e}")

    @app.post("/api/explain")
    async def explain(payload: dict):
        return await run_in_threadpool(advisor.explain, payload.get("check_id", ""), payload.get("lang", "en"))

    @app.post("/api/chat")
    async def chat(payload: dict):
        q = (payload.get("question") or "").strip()
        if not q:
            raise HTTPException(400, "empty question")
        return await run_in_threadpool(advisor.chat, payload.get("check_id", ""), q, payload.get("lang", "en"))

    @app.get("/api/history")
    def history(n: int = 30):
        return advisor.history.recent(min(n, 200))

    @app.post("/api/stt")
    async def speech_to_text(audio: UploadFile = File(...), lang: str = Form("en")):
        if not stt.available():
            raise HTTPException(501, "speech-to-text not configured")
        return {"text": stt.transcribe(await audio.read(), lang)}

    @app.post("/api/tts")
    async def text_to_speech(payload: dict):
        lang = payload.get("lang", "en")
        if not tts.available(lang):
            raise HTTPException(501, "text-to-speech not available for this language")
        return Response(tts.speak(payload.get("text", ""), lang), media_type="audio/wav")

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app


def main(argv=None):
    ap = argparse.ArgumentParser(description="Uzhavan AI offline crop advisor")
    ap.add_argument("--config", default=None)
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--analyze", metavar="IMAGE", help="run one image through the pipeline and print JSON")
    ap.add_argument("--lang", default="en")
    ap.add_argument("--zone", default="")
    ap.add_argument("--crop", default="")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_settings(a.config)
    if a.analyze:
        from .pipeline import Advisor
        p = Path(a.analyze)
        rec = Advisor(cfg).analyze(p.read_bytes(), a.lang, a.zone or None, a.crop or None, None, p.name, True)
        rec["severity"]["overlay_jpeg_b64"] = "<omitted>"
        json.dump(rec, sys.stdout, ensure_ascii=False, indent=2)
        print()
        return
    import uvicorn
    s = cfg.get("server", {})
    uvicorn.run(create_app(cfg), host=a.host or s.get("host", "0.0.0.0"), port=a.port or int(s.get("port", 8080)))


if __name__ == "__main__":
    main()
