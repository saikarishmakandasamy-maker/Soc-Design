"""End-to-end advisory pipeline.

  photo ─► quality check ─► vision (ExecuTorch / HailoRT) ─► severity (OpenCV)
        ─► knowledge base + region rules ─► FACTS ─► Llama 3.2 (ExecuTorch, CPU)
        ─► guard ─► [optional offline translation] ─► advice card + explanation
"""
from __future__ import annotations

import base64
import calendar
import io
import logging
import threading
import time
import uuid

from PIL import Image, ImageOps

from . import severity as sev
from .config import load_settings, resolve
from .history import History
from .i18n import norm_lang, t
from .i18n.translate import build_translator
from .knowledge.kb import SEV_ORDER, KnowledgeBase, pick
from .knowledge.regions import Regions
from .llm import guard, prompt, template
from .llm.runner import build_llm
from .vision import build_vision

log = logging.getLogger(__name__)


class Advisor:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or load_settings()
        self.kb = KnowledgeBase.load()
        self.regions = Regions.load()
        from .llm.runner import set_threads
        set_threads(int(self.cfg.get("llm", {}).get("threads", 0)))   # before any model runs
        self._vision_lock = threading.Lock()
        self.vision = build_vision(self.cfg)
        self.llm = build_llm(self.cfg)
        self.translator = build_translator(self.cfg)
        self.history = History(resolve(self.cfg.get("server", {}).get("history_db", "data/history.db")))
        v = self.cfg.get("vision", {})
        self.conf_threshold = float(v.get("confidence_threshold", 0.6))
        s = self.cfg.get("severity", {})
        self.mild_max, self.mod_max = float(s.get("mild_max_pct", 10)), float(s.get("moderate_max_pct", 25))
        self.native_langs = set(self.cfg.get("llm", {}).get("native_languages", ["en", "hi"]))

    # ------------------------------------------------------------------ status
    def status(self) -> dict:
        return {"vision_backend": self.vision.name, "vision_labels": len(self.vision.labels),
                "llm_backend": self.llm.backend, "llm_available": self.llm.available(),
                "translation": self.translator.name,
                "kb_verification": self.kb.meta.get("verification_status")}

    # ------------------------------------------------------------------- facts
    def _facts(self, cid, conf, top, sev_res, grade, region, lang, uncertain) -> dict:
        c = self.kb.get(cid) or {"type": "unknown", "crop": "multi", "name": {"en": cid}}
        # Llama gets facts in the output language when it writes that language natively;
        # otherwise English facts, and the answer is translated afterwards.
        flang = lang if lang in self.native_langs else "en"
        actions = [] if uncertain else self.kb.actions_for(cid, grade, flang)
        has_chem = any(a.type == "chemical" for a in actions)
        return {
            "condition_id": cid, "type": c["type"], "crop_id": c["crop"],
            "crop": pick(self.kb.crops.get(c["crop"]), flang),
            "problem": pick(c["name"], flang), "problem_local": pick(c["name"], lang),
            "pathogen": c.get("pathogen"), "symptoms": pick(c.get("symptoms"), flang),
            "favoured_by": pick(c.get("favoured_by"), flang),
            "confidence_pct": round(conf * 100), "uncertain": uncertain,
            "alternatives": [pick(self.kb.get(x.label)["name"], flang) + f" ({round(x.confidence * 100)}%)"
                             for x in top[1:] if self.kb.get(x.label) and x.confidence >= 0.1],
            "severity": grade, "lesion_pct": sev_res.lesion_pct,
            "urgent": bool(c.get("urgent")), "no_cure": bool(c.get("no_cure")),
            "region": region["zone_name"] if region["zone"] != "generic" else "",
            "month_name": calendar.month_name[region["month"]],
            "seasonal_notes": region["seasonal_notes"] if flang == lang else
                              self.regions.context(region["zone"], cid, "en", region["month"])["seasonal_notes"],
            "actions": [{"type": a.type, "text": a.text} for a in actions],
            "prevention": pick(c.get("prevention"), flang),
            "has_chemical": has_chem, "safety": " ".join(self.kb.safety(flang)[:2]),
            "escalate": grade == "severe" and c["type"] != "healthy",
        }

    # ------------------------------------------------------------------ explain
    def _explain(self, facts: dict, lang: str, question: str | None = None) -> dict:
        if facts.get("type") == "unsupported":
            msg = t("unsupported_msg", lang)
            return {"text": msg, "speech": msg, "source": "card", "language": lang}
        if question:
            lf = self._local_facts(facts, lang)
            card = template.chat_from_card(question, lf, self.kb.safety(lang), lang)
            if card:
                # Common questions (dose, organic, prevention, spread, safety) are answered straight
                # from the vetted card: instant, exact doses, nothing for the LLM to get wrong.
                return {"text": card, "speech": card, "source": "card", "language": lang}
            tpl = speech = template.chat_fallback(lang)
        else:
            lf = self._local_facts(facts, lang)
            tpl, speech = template.advisory_text(lf, lang, short=True), template.advisory_text(lf, lang)
        if not self.llm.available():
            return {"text": tpl, "speech": speech, "source": "template", "language": lang,
                    "note": t("llm_unavailable", lang)}
        gen_lang = lang if lang in self.native_langs else "en"
        p = prompt.chat_prompt(facts, question, gen_lang) if question else prompt.advisory_prompt(facts, gen_lang)
        try:
            g = self.llm.generate(p)
        except Exception as e:
            log.exception("LLM generation failed")
            return {"text": tpl, "speech": speech, "source": "template", "language": lang, "note": f"LLM error: {e}"}
        facts_text = prompt.facts_block(facts) + (f" {question}" if question else "")
        gr = guard.check(g.text, facts_text, gen_lang)
        meta = {"llm_backend": g.backend, "latency_ms": round(g.latency_ms), "tokens_per_s": g.tokens_per_s,
                "generated_tokens": g.generated_tokens, "guard": {"ok": gr.ok, "violations": gr.violations}}
        if not gr.ok:
            log.warning("guard rejected LLM output: %s | %r", gr.violations, g.text[:200])
            return {"text": tpl, "speech": speech, "source": "template", "language": lang,
                    "rejected_llm_text": g.text, **meta}
        text, source = g.text, "llm"
        if gen_lang != lang:
            if self.translator.available(lang):
                text, source = self.translator.translate(text, lang), "llm+translation"
            else:
                source = "llm-english"  # UI shows the localised card plus this English explanation
        out_lang = lang if source != "llm-english" else "en"
        return {"text": text, "speech": text, "source": source, "language": out_lang, **meta}

    def _local_facts(self, facts: dict, lang: str) -> dict:
        """Facts re-rendered in the UI language for the template text."""
        if facts.get("_lang") == lang:
            return facts
        c = self.kb.get(facts["condition_id"]) or {}
        acts = [] if facts["uncertain"] else self.kb.actions_for(facts["condition_id"], facts["severity"], lang)
        return {**facts, "crop": pick(self.kb.crops.get(facts["crop_id"]), lang),
                "problem_local": pick(c.get("name"), lang), "prevention": pick(c.get("prevention"), lang),
                "symptoms_local": pick(c.get("symptoms"), lang), "favoured_local": pick(c.get("favoured_by"), lang),
                "actions": [{"type": a.type, "text": a.text} for a in acts]}

    # ----------------------------------------------------------------- analyse
    def analyze(self, image_bytes: bytes, lang: str = "en", zone: str | None = None, crop: str | None = None,
                severity_override: str | None = None, filename: str | None = None, explain: bool = True,
                label_override: str | None = None) -> dict:
        lang = norm_lang(lang)
        t0 = time.perf_counter()
        img = ImageOps.exif_transpose(Image.open(io.BytesIO(image_bytes))).convert("RGB")
        quality = sev.check_quality(img)
        allowed = self.kb.labels_for_crop(crop)
        exclude = {"unsupported"} if crop else None   # the farmer named the crop: never answer "not in my list"
        with self._vision_lock:
            if self.vision.name.startswith("mock"):
                vr = self.vision.predict(img, allowed, hint=filename, exclude=exclude)
            else:
                vr = self.vision.predict(img, allowed, exclude=exclude)
        cid, conf, vsource = vr.label, vr.confidence, "model"
        picked = self.kb.get(label_override or "")
        if picked and picked["type"] != "unsupported":
            # The farmer tapped one of the candidates ("closest match"): trust their confirmation.
            cid, vsource = label_override, "farmer"
            conf = next((c.confidence for c in vr.top_k if c.label == cid), conf)
        low_conf = conf < self.conf_threshold and vsource == "model"
        if low_conf and (self.kb.get(cid) or {}).get("type") == "unsupported":
            # A weak "not in my list" is just "not sure": show the best real candidates instead,
            # so a grape farmer with a dark, blurry photo is not told grape is unsupported.
            real = [c for c in vr.top_k if (self.kb.get(c.label) or {}).get("type") != "unsupported"]
            if real:
                cid, conf = real[0].label, real[0].confidence
        cond = self.kb.get(cid) or {"type": "unknown", "crop": "multi", "name": {"en": cid}}
        unsupported = cond["type"] == "unsupported"   # confident: crop/disease the model doesn't cover
        uncertain = low_conf or unsupported
        healthy = cond["type"] == "healthy"
        s = sev.estimate(img, self.mild_max, self.mod_max, healthy=healthy or unsupported)
        grade, grade_src = s.grade, "image"
        if severity_override in SEV_ORDER and not healthy and not unsupported:
            grade, grade_src = severity_override, "farmer"
        region = self.regions.context(zone, cid, lang)
        facts = self._facts(cid, conf, vr.top_k, s, grade, region, lang, uncertain)
        local = self._local_facts(facts, lang)
        card_actions = [] if uncertain else [a.__dict__ for a in self.kb.actions_for(cid, grade, lang)]
        rid = uuid.uuid4().hex[:12]
        rec = {
            "id": rid, "language": lang,
            "quality": {**quality.__dict__, "messages": [t(f"quality_{i}", lang) for i in quality.issues]},
            "vision": {"backend": vr.backend, "label": cid, "confidence": round(conf, 4), "uncertain": uncertain,
                       "source": vsource, "model_label": vr.label,
                       "latency_ms": round(vr.latency_ms, 1),
                       "top_k": [{"label": c.label, "confidence": round(c.confidence, 4),
                                  "name": pick((self.kb.get(c.label) or {}).get("name"), lang) or c.label,
                                  "type": (self.kb.get(c.label) or {}).get("type"),
                                  "crop": (self.kb.get(c.label) or {}).get("crop"),
                                  "crop_name": pick(self.kb.crops.get((self.kb.get(c.label) or {}).get("crop")), lang)}
                                 for c in vr.top_k]},
            "severity": {"lesion_pct": s.lesion_pct, "grade": grade, "image_grade": s.grade, "source": grade_src,
                         "overlay_jpeg_b64": s.overlay_jpeg_b64},
            "condition": {"id": cid, "type": cond["type"], "crop": cond["crop"],
                          "crop_name": local["crop"], "name": local["problem_local"],
                          "pathogen": cond.get("pathogen"), "urgent": bool(cond.get("urgent")),
                          "symptoms": pick(cond.get("symptoms"), lang), "favoured_by": pick(cond.get("favoured_by"), lang),
                          "no_cure": bool(cond.get("no_cure"))},
            "region": region,
            "advisory": {"actions": card_actions, "prevention": local["prevention"],
                         "safety": self.kb.safety(lang) if any(a["type"] == "chemical" for a in card_actions) else [],
                         "escalate": facts["escalate"], "unverified_notice": t("unverified", lang)},
        }
        thumb = img.copy()
        thumb.thumbnail((96, 96))
        buf = io.BytesIO()
        thumb.save(buf, "JPEG", quality=70)
        self.history.add(rec, facts, base64.b64encode(buf.getvalue()).decode())
        # explain=False lets the UI show the card at once and fetch the LLM text via explain()
        explain = explain or uncertain            # unsure / unsupported: nothing for the LLM to explain; answer at once
        rec["advisory"]["explanation"] = self._explain(facts, lang) if explain else None
        rec["llm_pending"] = not explain and self.llm.available()
        rec["timing_ms"] = round((time.perf_counter() - t0) * 1000)
        return rec

    def explain(self, check_id: str, lang: str = "en") -> dict:
        """LLM (or template) explanation for a stored check — called after the card is shown."""
        lang = norm_lang(lang)
        facts = self.history.facts(check_id)
        if not facts:
            return {"text": t("chat_fallback", lang), "speech": t("chat_fallback", lang), "source": "template"}
        return self._explain(facts, lang)

    def chat(self, check_id: str, question: str, lang: str = "en") -> dict:
        lang = norm_lang(lang)
        facts = self.history.facts(check_id)
        if not facts:
            return {"text": t("chat_fallback", lang), "source": "template"}
        return self._explain(facts, lang, question=question)
