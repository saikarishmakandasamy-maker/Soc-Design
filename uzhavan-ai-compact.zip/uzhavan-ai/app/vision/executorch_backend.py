"""Vision inference through the ExecuTorch runtime (XNNPACK delegate on Arm CPU)."""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
from PIL import Image

from .base import VisionBackend, VisionResult, rank, softmax, to_nchw_float


class ExecuTorchVision(VisionBackend):
    name = "executorch-xnnpack"

    def __init__(self, model_path: Path, labels, img_size=224, top_k=3, threads: int = 0):
        super().__init__(labels, img_size, top_k)
        import torch  # ExecuTorch's Python runtime takes torch tensors
        self._torch = torch
        if threads:
            torch.set_num_threads(threads)
        if not Path(model_path).exists():
            raise FileNotFoundError(f"vision model not found: {model_path}")
        try:
            from executorch.runtime import Runtime
            self._program = Runtime.get().load_program(str(model_path))
            self._method = self._program.load_method("forward")
            self._run = lambda t: self._method.execute([t])
        except ImportError:  # older ExecuTorch builds
            from executorch.extension.pybindings.portable_lib import _load_for_executorch
            self._module = _load_for_executorch(str(model_path))
            self._run = lambda t: self._module.forward((t,))

    def predict(self, img: Image.Image, allowed=None, exclude=None) -> VisionResult:
        x = self._torch.from_numpy(to_nchw_float(img, self.img_size))
        t0 = time.perf_counter()
        out = self._run(x)
        ms = (time.perf_counter() - t0) * 1000
        logits = np.asarray(out[0].detach().numpy() if hasattr(out[0], "detach") else out[0])
        top = rank(softmax(logits), self.labels, self.top_k, allowed, exclude)
        return VisionResult(top[0].label, top[0].confidence, top, self.name, ms)
