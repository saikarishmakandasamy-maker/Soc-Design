"""Grounded prompts for Llama 3.2 Instruct.

The model is given a FACTS block built only from the vision result, the
severity estimate, the knowledge base and the region table. It is told to
rephrase those facts, never to add treatments. guard.py then enforces that.
"""
from __future__ import annotations

LANG_NAMES = {"en": "simple English", "hi": "simple Hindi in Devanagari script", "ta": "simple Tamil in Tamil script"}

SYSTEM = (
    "You are Uzhavan, an agricultural extension assistant for small farmers in India. "
    "You explain a crop diagnosis in plain, friendly words a farmer can follow.\n"
    "RULES:\n"
    "1. Use ONLY the information in FACTS. Do not add facts.\n"
    "2. Never name a chemical, product, brand or dose that is not in FACTS. Copy doses exactly as written.\n"
    "3. If FACTS say the result is uncertain, say that first and ask the farmer to retake the photo "
    "or show the plant to the agriculture officer. Do not recommend sprays in that case.\n"
    "4. If FACTS say there is no cure, say so clearly.\n"
    "5. At most 6 short sentences. No headings, no lists, no markdown.\n"
    "6. Write the whole answer in {language}."
)


def facts_block(f: dict) -> str:
    lines = [f"- crop: {f['crop']}", f"- problem: {f['problem']}"]
    if f.get("pathogen"):
        lines.append(f"- cause: {f['pathogen']}")
    lines.append(f"- confidence: {f['confidence_pct']}% ({'uncertain' if f['uncertain'] else 'reliable'})")
    if f.get("alternatives"):
        lines.append(f"- other possibilities: {', '.join(f['alternatives'])}")
    if f["type"] != "healthy":
        lines.append(f"- severity: {f['severity']} (about {f['lesion_pct']}% of the leaf is damaged)")
    if f.get("urgent"):
        lines.append("- urgent: yes, it spreads fast; act today")
    if f.get("no_cure"):
        lines.append("- no cure: no spray cures this; remove sick plants")
    if f.get("symptoms"):
        lines.append(f"- typical signs: {f['symptoms']}")
    if f.get("favoured_by"):
        lines.append(f"- spreads when: {f['favoured_by']}")
    if f.get("region"):
        lines.append(f"- farmer's area: {f['region']}; month: {f['month_name']}")
    for n in f.get("seasonal_notes", []):
        lines.append(f"- seasonal risk: {n}")
    if f.get("actions") and not f["uncertain"]:
        lines.append("- allowed actions:")
        for i, a in enumerate(f["actions"], 1):
            lines.append(f"  {i}. [{a['type']}] {a['text']}")
    if f.get("prevention"):
        lines.append(f"- prevention: {f['prevention']}")
    if f.get("has_chemical"):
        lines.append(f"- safety: {f['safety']}")
    if f.get("escalate"):
        lines.append("- also contact the local agriculture officer or Krishi Vigyan Kendra")
    return "FACTS:\n" + "\n".join(lines)


def _chat(system: str, user: str) -> str:
    return ("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n" + system +
            "<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n" + user +
            "<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n")


def advisory_prompt(facts: dict, lang: str) -> str:
    if facts["uncertain"]:
        task = "TASK: Say you are not sure what the problem is and ask the farmer to retake the photo or ask the agriculture officer. 2 sentences."
    elif facts["type"] == "healthy":
        task = "TASK: In 2 sentences, tell the farmer the leaf looks healthy and what to keep checking."
    else:
        task = ("TASK: Write 4 to 6 short sentences. Sentence 1: name the problem and the crop. "
                "Then give the allowed actions in the same order, copying any dose exactly. "
                "Then one sentence on prevention. No greeting, no closing remarks.")
    return _chat(SYSTEM.format(language=LANG_NAMES.get(lang, "simple English")), facts_block(facts) + "\n\n" + task)


def chat_prompt(facts: dict, question: str, lang: str) -> str:
    """Facts live in the system turn; the farmer's question is the user turn on its own.
    Putting the question inside a long facts block made Llama 1B continue *as the farmer*."""
    system = (SYSTEM.format(language=LANG_NAMES.get(lang, "simple English")) + "\n\n" + facts_block(facts) +
              "\n\nYou are the advisor. The user is the farmer who sent the photo. Speak to the farmer as 'you'. "
              "Answer in at most 3 sentences using only FACTS. If FACTS do not contain the answer, say you are "
              "not sure and suggest asking the local agriculture officer.")
    return _chat(system, question.strip()[:400])
