"""Output guard for LLM advice.

A 1B model can still invent a pesticide or a dose. Before any generated text
reaches the farmer we check:
  * every chemical name mentioned is one of the actions allowed for this case
  * every number in the answer also appears in the FACTS given to the model
  * the answer is in the requested script and is not empty
If any check fails, the app shows the knowledge-base template instead and the
violation is logged (and shown in the debug panel).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# Common agrochemicals a small model may hallucinate. Lower-case base names.
KNOWN_CHEMICALS = {
    "mancozeb", "metalaxyl", "cymoxanil", "tricyclazole", "emamectin", "spinetoram", "copper oxychloride",
    "copper hydroxide", "carbendazim", "propiconazole", "hexaconazole", "tebuconazole", "difenoconazole",
    "azoxystrobin", "chlorothalonil", "thiophanate", "sulphur", "sulfur", "validamycin", "kasugamycin",
    "streptomycin", "streptocycline", "imidacloprid", "thiamethoxam", "acetamiprid", "clothianidin",
    "dinotefuran", "chlorpyrifos", "monocrotophos", "profenofos", "quinalphos", "dimethoate", "acephate",
    "malathion", "cypermethrin", "deltamethrin", "lambda-cyhalothrin", "lambda cyhalothrin", "fipronil",
    "chlorantraniliprole", "flubendiamide", "cartap", "carbofuran", "phorate", "buprofezin", "pymetrozine",
    "triflumezopyrim", "spinosad", "indoxacarb", "novaluron", "endosulfan", "ddt", "glyphosate", "paraquat",
    "2,4-d", "atrazine", "butachlor", "pretilachlor", "bordeaux", "neem", "trichoderma", "pseudomonas",
    "bacillus", "beauveria", "metarhizium", "trichogramma", "urea", "potash", "zinc",
}
_DEV_DIGITS = str.maketrans("०१२३४५६७८९", "0123456789")
_TA_DIGITS = str.maketrans("௦௧௨௩௪௫௬௭௮௯", "0123456789")
_NUM = re.compile(r"\d+(?:\.\d+)?")
# The model answering as if it were the farmer ("I'm not sure how to treat my plants…").
_ROLE_FLIP = re.compile(
    r"\bmy (?:crop|crops|plant|plants|tomato|tomatoes|potato|potatoes|maize|rice|paddy|field|farm|leaves)\b"
    r"|\bi(?:'ve| have) been told\b|\bi(?:'m| am) not sure how to (?:treat|mix|spray|use)\b"
    r"|मेरी फसल|मेरे पौध|मेरे खेत|मुझे बताया गया|என் பயிர்|என் செடி|என் வயல்")
SCRIPTS = {"hi": re.compile(r"[ऀ-ॿ]"), "ta": re.compile(r"[஀-௿]")}


@dataclass
class GuardResult:
    ok: bool
    violations: list[str] = field(default_factory=list)


def _norm_digits(s: str) -> str:
    return s.translate(_DEV_DIGITS).translate(_TA_DIGITS)


def _numbers(s: str) -> set[str]:
    out = set()
    for n in _NUM.findall(_norm_digits(s)):
        out.add(n)
        if "." in n:
            out.add(n.rstrip("0").rstrip("."))
    return out


def check(text: str, facts_text: str, lang: str, check_script: bool = True) -> GuardResult:
    v = []
    t = text.strip()
    if len(t) < 20:
        v.append("empty_or_too_short")
    low, facts_low = t.lower(), facts_text.lower()
    for chem in KNOWN_CHEMICALS:
        if re.search(rf"(?<![a-z]){re.escape(chem)}(?![a-z])", low) and chem not in facts_low:
            v.append(f"unlisted_chemical:{chem}")
    extra = _numbers(t) - _numbers(facts_text) - {"1", "2", "3", "4", "5", "6"}  # allow list numbering
    for n in sorted(extra):
        v.append(f"unlisted_number:{n}")
    if _ROLE_FLIP.search(low):
        v.append("speaks_as_farmer")
    if check_script and lang in SCRIPTS:
        letters = [c for c in t if c.isalpha()]
        native = len(SCRIPTS[lang].findall(t))
        if letters and native / len(letters) < 0.5:
            v.append("wrong_language")
    return GuardResult(not v, v)
