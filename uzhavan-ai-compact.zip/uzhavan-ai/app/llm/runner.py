"""Llama 3.2 on-device inference through ExecuTorch.

Two interchangeable paths, both running the same exported .pte on the Arm CPU
(XNNPACK + KleidiAI kernels):

  python : executorch.extension.llm.runner.TextLLMRunner (model stays loaded)
  binary : ExecuTorch's `llama_main` C++ runner launched per request

`mode: auto` tries python first, then binary.
"""
from __future__ import annotations

import logging
import re
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from ..config import resolve

log = logging.getLogger(__name__)
_SPECIAL = re.compile(r"<\|[a-z_]+\|>")


@dataclass
class Generation:
    text: str
    backend: str
    latency_ms: float
    prompt_tokens: int | None = None
    generated_tokens: int | None = None
    tokens_per_s: float | None = None


def default_threads() -> int:
    """Physical-ish core count: logical CPUs halved on SMT machines (laptops), all cores on
    small Arm boards (Pi 5 has 4 cores, no SMT)."""
    import os
    n = os.cpu_count() or 1
    return n // 2 if n >= 8 else n


def set_threads(threads: int = 0) -> int:
    """Size ExecuTorch's shared CPU threadpool (used by XNNPACK for both the vision model and
    Llama — libexecutorch_threadpool.so is shared by the pybindings and the LLM runner).
    Must be called before any inference starts."""
    n = threads or default_threads()
    try:
        from executorch.extension.pybindings import portable_lib as pl
        before = pl._threadpool_get_thread_count()
        if before != n:
            pl._unsafe_reset_threadpool(n)
        log.info("ExecuTorch threadpool: %s -> %s threads", before, pl._threadpool_get_thread_count())
        return n
    except Exception as e:  # pragma: no cover
        log.warning("could not set ExecuTorch threads: %s", e)
        return 0


def clean(text: str) -> str:
    text = text.split("<|eot_id|>")[0]
    text = _SPECIAL.sub("", text)
    return re.sub(r"[ \t]+", " ", text).strip()


class LlamaRunner:
    backend = "none"

    def available(self) -> bool:
        return False

    def generate(self, prompt: str) -> Generation:  # pragma: no cover
        raise RuntimeError("LLM not available")


class PythonExecuTorchLlama(LlamaRunner):
    backend = "executorch-python"

    def __init__(self, model: Path, tokenizer: Path, seq_len: int, max_new: int, temperature: float,
                 threads: int = 0):
        # Exports with use_sdpa_with_kv_cache / quantized embeddings use ExecuTorch custom ops
        # (llama::custom_sdpa, llama::update_cache, quantized_decomposed::*). Importing these
        # modules registers their kernels with the runtime; without it 'forward' fails to load.
        for mod in ("executorch.extension.llm.custom_ops.custom_ops", "executorch.kernels.quantized"):
            try:
                __import__(mod)
            except Exception as e:  # pragma: no cover
                log.warning("could not load %s: %s", mod, e)
        set_threads(threads)
        from executorch.extension.llm.runner import GenerationConfig, TextLLMRunner
        self._cfg_cls = GenerationConfig
        self._runner = TextLLMRunner(str(model), str(tokenizer))
        self.seq_len, self.max_new, self.temperature = seq_len, max_new, temperature
        self._lock = threading.Lock()

    def available(self) -> bool:
        return True

    def generate(self, prompt: str) -> Generation:
        cfg = self._cfg_cls(echo=False, max_new_tokens=self.max_new, seq_len=self.seq_len,
                            temperature=self.temperature, num_bos=0, num_eos=0)
        pieces, stats = [], {}

        def on_stats(s):
            stats.update(prompt=s.num_prompt_tokens, gen=s.num_generated_tokens,
                         first=s.first_token_ms, start=s.inference_start_ms, end=s.inference_end_ms)

        with self._lock:
            self._runner.reset()
            t0 = time.perf_counter()
            self._runner.generate(prompt, cfg, pieces.append, on_stats)
            ms = (time.perf_counter() - t0) * 1000
        tps = None
        if stats.get("gen") and stats.get("end") and stats.get("first") and stats["end"] > stats["first"]:
            tps = stats["gen"] / ((stats["end"] - stats["first"]) / 1000)
        return Generation(clean("".join(pieces)), self.backend, ms, stats.get("prompt"), stats.get("gen"),
                          round(tps, 1) if tps else None)


class BinaryExecuTorchLlama(LlamaRunner):
    backend = "executorch-llama_main"

    def __init__(self, binary: Path, model: Path, tokenizer: Path, seq_len: int, temperature: float,
                 threads: int, timeout: int):
        self.cmd = [str(binary), f"--model_path={model}", f"--tokenizer_path={tokenizer}",
                    f"--seq_len={seq_len}", f"--temperature={temperature}"]
        if threads:
            self.cmd.append(f"--cpu_threads={threads}")
        self.timeout = timeout
        self._lock = threading.Lock()

    def available(self) -> bool:
        return True

    def generate(self, prompt: str) -> Generation:
        with self._lock:
            t0 = time.perf_counter()
            p = subprocess.run(self.cmd + [f"--prompt={prompt}"], capture_output=True, text=True,
                               timeout=self.timeout)
            ms = (time.perf_counter() - t0) * 1000
        if p.returncode != 0:
            raise RuntimeError(f"llama_main failed ({p.returncode}): {p.stderr[-400:]}")
        return Generation(parse_llama_main(p.stdout, prompt), self.backend, ms)


def parse_llama_main(stdout: str, prompt: str) -> str:
    """llama_main echoes the prompt, streams tokens, then prints stats lines."""
    out = stdout
    marker = "assistant<|end_header_id|>"
    if marker in out:
        out = out.rsplit(marker, 1)[1]
    elif out.startswith(prompt):
        out = out[len(prompt):]
    keep = [l for l in out.splitlines()
            if not l.startswith(("PyTorchObserver", "I 00:", "E 00:", "W 00:")) and "tokens/second" not in l]
    return clean("\n".join(keep))


def build_llm(cfg: dict) -> LlamaRunner:
    c = cfg.get("llm", {})
    if not c.get("enabled", True):
        return LlamaRunner()
    model, tok = resolve(c.get("model_path")), resolve(c.get("tokenizer_path"))
    if not (model and model.exists() and tok and tok.exists()):
        log.warning("Llama model/tokenizer not found (%s, %s) — template advisory only", model, tok)
        return LlamaRunner()
    mode = c.get("mode", "auto")
    seq, new, temp = int(c.get("seq_len", 2048)), int(c.get("max_new_tokens", 150)), float(c.get("temperature", 0.2))
    if mode in ("auto", "python"):
        try:
            return PythonExecuTorchLlama(model, tok, seq, new, temp, int(c.get("threads", 0)))
        except Exception as e:
            log.warning("TextLLMRunner unavailable: %s", e)
    if mode in ("auto", "binary"):
        binary = resolve(c.get("runner_binary"))
        if binary and binary.exists():
            return BinaryExecuTorchLlama(binary, model, tok, seq, temp, int(c.get("threads", 0)),
                                         int(c.get("timeout_s", 90)))
        log.warning("llama_main not found at %s", binary)
    return LlamaRunner()
