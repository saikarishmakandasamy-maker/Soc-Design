"""Severity estimation and photo-quality checks with OpenCV.

Severity = diseased (non-green) area / total leaf area inside the main leaf.
This is deliberately simple and explainable: the overlay shows exactly which
pixels were counted, so a farmer or extension worker can see why the app said
"moderate". It works best on a single leaf filling most of the frame.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass, field

import cv2
import numpy as np
from PIL import Image

GRADES = ("none", "mild", "moderate", "severe")


@dataclass
class Quality:
    ok: bool
    blur_score: float
    brightness: float
    leaf_coverage: float
    issues: list[str] = field(default_factory=list)


@dataclass
class Severity:
    lesion_pct: float
    grade: str
    leaf_pixels: int
    overlay_jpeg_b64: str | None = None


def pil_to_bgr(img: Image.Image, max_side: int = 512) -> np.ndarray:
    img = img.convert("RGB")
    w, h = img.size
    s = min(1.0, max_side / max(w, h))
    if s < 1.0:
        img = img.resize((round(w * s), round(h * s)), Image.BILINEAR)
    return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)


def _largest_filled(m: np.ndarray) -> np.ndarray:
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m, 8)
    if n <= 1:
        return np.zeros_like(m)
    biggest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    m = np.where(lab == biggest, 255, 0).astype(np.uint8)
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filled = np.zeros_like(m)
    cv2.drawContours(filled, contours, -1, 255, thickness=cv2.FILLED)
    return filled


def _background_distance(bgr: np.ndarray, strip: int = 6):
    """Lab distance of every pixel to the median colour of the image border.
    Returns (distance map, True if the border looks like a uniform background)."""
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    border = np.concatenate([lab[:strip].reshape(-1, 3), lab[-strip:].reshape(-1, 3),
                             lab[:, :strip].reshape(-1, 3), lab[:, -strip:].reshape(-1, 3)])
    ref = np.median(border, axis=0)
    dist = np.linalg.norm(lab - ref, axis=2)
    bdist = np.linalg.norm(border - ref, axis=1)
    uniform = float(np.mean(bdist < 25)) > 0.5
    return dist, uniform


def leaf_mask(bgr: np.ndarray, grabcut: bool = True) -> np.ndarray:
    """Mask of the main leaf.

    1. seed: plant-coloured pixels (green / yellow / brown, saturated) that are
       not the colour of a uniform background seen at the image border
    2. GrabCut refinement on a 256-px copy (cheap enough for a Pi 5)
    3. largest connected region, holes filled so dark necrotic lesions inside
       the leaf stay in the denominator."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    b, g, r = [c.astype(np.int16) for c in cv2.split(bgr)]
    green = ((2 * g - r - b) > 15) & (v > 30)
    greenish = (h >= 27) & (h <= 95) & (s > 45) & (v > 35)
    brownish = (h < 27) & (s > 70) & (v > 35)        # yellow/brown tissue; backgrounds are rarely this saturated
    seed = green | greenish | brownish
    dist, uniform = _background_distance(bgr)
    bh, bs = np.median(np.concatenate([h[:6].ravel(), h[-6:].ravel()])), np.median(np.concatenate([s[:6].ravel(), s[-6:].ravel()]))
    if 27 <= bh <= 95 and bs > 45:   # leaf fills the frame: the border is leaf, not background
        uniform = False
    if uniform:
        seed &= dist > 18
    m = seed.astype(np.uint8) * 255
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k, iterations=2)
    m = _largest_filled(m)
    if grabcut and m.any() and 0.02 < (m > 0).mean() < 0.98:
        hh, ww = m.shape
        sc = 256 / max(hh, ww)
        small = cv2.resize(bgr, (round(ww * sc), round(hh * sc)), interpolation=cv2.INTER_AREA)
        ms = cv2.resize(m, small.shape[1::-1], interpolation=cv2.INTER_NEAREST)
        gc = np.where(ms > 0, cv2.GC_PR_FGD, cv2.GC_PR_BGD).astype(np.uint8)
        gc[cv2.erode(ms, k, iterations=3) > 0] = cv2.GC_FGD
        if uniform:
            ds = cv2.resize(dist, small.shape[1::-1], interpolation=cv2.INTER_NEAREST)
            gc[(ds < 9) & (ms == 0)] = cv2.GC_BGD
        try:
            bgd, fgd = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
            cv2.grabCut(small, gc, None, bgd, fgd, 3, cv2.GC_INIT_WITH_MASK)
            ref = np.where((gc == cv2.GC_FGD) | (gc == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
            ref = cv2.resize(ref, (ww, hh), interpolation=cv2.INTER_NEAREST)
            ref = _largest_filled(cv2.morphologyEx(ref, cv2.MORPH_OPEN, k))
            if ref.any():
                m = ref
        except cv2.error:
            pass
    # Cast shadows (very dark, or dark-grey) cut from the leaf edge. Re-filling holes
    # afterwards restores dark lesions that lie *inside* the leaf outline.
    shadow = (v < 38) | ((s < 40) & (v < 120))
    trimmed = cv2.morphologyEx(np.where(shadow, 0, m).astype(np.uint8), cv2.MORPH_OPEN, k)
    trimmed = _largest_filled(trimmed)
    if (trimmed > 0).sum() > 0.4 * (m > 0).sum():
        m = trimmed
    return m


def lesion_mask(bgr: np.ndarray, leaf: np.ndarray) -> np.ndarray:
    """Inside the leaf: brown/yellow/necrotic tissue. Pale veins and specular
    highlights (low saturation, bright) are treated as healthy, not damage."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    healthy = (h >= 27) & (h <= 95) & (s >= 38) & (v >= 40)
    neutral = (s < 45) & (v >= 140)          # veins, glare
    les = (leaf > 0) & ~healthy & ~neutral
    les = cv2.morphologyEx(les.astype(np.uint8) * 255, cv2.MORPH_OPEN,
                           cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    return les


def grade_for(pct: float, mild_max: float, moderate_max: float, healthy: bool) -> str:
    if healthy or pct < 1.0:
        return "none" if healthy else "mild"
    if pct <= mild_max:
        return "mild"
    if pct <= moderate_max:
        return "moderate"
    return "severe"


def overlay(bgr: np.ndarray, leaf: np.ndarray, les: np.ndarray) -> str:
    out = bgr.copy()
    red = np.zeros_like(out)
    red[:] = (40, 40, 230)
    sel = les > 0
    out[sel] = cv2.addWeighted(out, 0.35, red, 0.65, 0)[sel]
    contours, _ = cv2.findContours(leaf, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(out, contours, -1, (60, 220, 60), 2)
    ok, buf = cv2.imencode(".jpg", out, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return base64.b64encode(buf.tobytes()).decode() if ok else ""


def check_quality(img: Image.Image) -> Quality:
    bgr = pil_to_bgr(img)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    bright = float(gray.mean())
    cov = float((leaf_mask(bgr) > 0).mean())
    issues = []
    if blur < 40:
        issues.append("blurry")
    if bright < 45:
        issues.append("too_dark")
    elif bright > 225:
        issues.append("too_bright")
    if cov < 0.08:
        issues.append("leaf_too_small")
    return Quality(not issues, round(blur, 1), round(bright, 1), round(cov, 3), issues)


def estimate(img: Image.Image, mild_max=10.0, moderate_max=25.0, healthy=False, with_overlay=True) -> Severity:
    bgr = pil_to_bgr(img)
    leaf = leaf_mask(bgr)
    n_leaf = int((leaf > 0).sum())
    if n_leaf == 0:
        return Severity(0.0, "none" if healthy else "mild", 0, None)
    les = lesion_mask(bgr, leaf)
    pct = 100.0 * float((les > 0).sum()) / n_leaf
    return Severity(round(pct, 1), grade_for(pct, mild_max, moderate_max, healthy), n_leaf,
                    overlay(bgr, leaf, les) if with_overlay else None)
