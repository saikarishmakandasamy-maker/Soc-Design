#!/usr/bin/env python3
"""Train the crop disease / pest image classifier.

Expects an ImageFolder-style tree: <data-dir>/<FolderName>/*.jpg, where every
FolderName appears in --label-map (folder -> knowledge-base id). Folders missing
from the map are skipped, so you can point this at the full PlantVillage tree.

Outputs (in --out):
  classifier.pt      best checkpoint (state_dict + metadata)
  labels.json        ordered list of knowledge-base ids (model output index -> id)
  metrics.json       accuracy, per-class accuracy, confusion matrix on the test split

Example:
  python training/train_classifier.py --data-dir datasets/PlantVillage/raw/color \
      --pretrained-path models/pretrained/mobilenetv3_large_100_ra-f55367f5.pth \
      --epochs 10 --out models/vision
"""
from __future__ import annotations

import argparse
import json
import random
import time
from collections import defaultdict
from pathlib import Path

import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms

import timm

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)
IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


class ListDataset(Dataset):
    def __init__(self, items, tf):
        self.items, self.tf = items, tf

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        path, y = self.items[i]
        img = Image.open(path).convert("RGB")
        return self.tf(img), y


def collect(data_dir: Path, label_map: dict[str, str]):
    folders = sorted(d for d in data_dir.iterdir() if d.is_dir() and d.name in label_map)
    if not folders:
        raise SystemExit(f"No folders in {data_dir} match the label map")
    labels = sorted({label_map[d.name] for d in folders})
    idx = {l: i for i, l in enumerate(labels)}
    per_class = defaultdict(list)
    for d in folders:
        for p in d.rglob("*"):
            if p.suffix.lower() in IMG_EXT:
                per_class[idx[label_map[d.name]]].append(str(p))
    return labels, per_class


def split(per_class, seed=0, val=0.1, test=0.1):
    rng = random.Random(seed)
    tr, va, te = [], [], []
    for y, paths in per_class.items():
        paths = sorted(paths)
        rng.shuffle(paths)
        n = len(paths)
        nt, nv = max(1, int(n * test)), max(1, int(n * val))
        te += [(p, y) for p in paths[:nt]]
        va += [(p, y) for p in paths[nt:nt + nv]]
        tr += [(p, y) for p in paths[nt + nv:]]
    return tr, va, te


def build_model(arch: str, num_classes: int, pretrained_path: str | None, pretrained_hub: bool):
    model = timm.create_model(arch, pretrained=pretrained_hub and not pretrained_path)
    if pretrained_path:
        sd = torch.load(pretrained_path, map_location="cpu")
        missing, unexpected = model.load_state_dict(sd, strict=False)
        print(f"loaded pretrained weights ({len(missing)} missing, {len(unexpected)} unexpected keys)")
    model.reset_classifier(num_classes)
    return model


@torch.no_grad()
def evaluate(model, loader, n_cls):
    model.eval()
    cm = [[0] * n_cls for _ in range(n_cls)]
    for x, y in loader:
        pred = model(x).argmax(1)
        for t, p in zip(y.tolist(), pred.tolist()):
            cm[t][p] += 1
    correct = sum(cm[i][i] for i in range(n_cls))
    total = sum(map(sum, cm))
    return correct / max(total, 1), cm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True, type=Path)
    ap.add_argument("--label-map", type=Path, default=Path(__file__).with_name("plantvillage_label_map.json"))
    ap.add_argument("--out", type=Path, default=Path("models/vision"))
    ap.add_argument("--arch", default="mobilenetv3_large_100")
    ap.add_argument("--pretrained-path", default=None, help="local timm weights file (offline)")
    ap.add_argument("--pretrained-hub", action="store_true", help="download timm ImageNet weights")
    ap.add_argument("--img-size", type=int, default=224)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=6e-4)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    if args.threads:
        torch.set_num_threads(args.threads)
    label_map = {k: v for k, v in json.loads(args.label_map.read_text()).items() if not k.startswith("_")}
    labels, per_class = collect(args.data_dir, label_map)
    tr, va, te = split(per_class, args.seed)
    print(f"{len(labels)} classes | train {len(tr)} val {len(va)} test {len(te)}")

    s = args.img_size
    # Field-style augmentation: PlantVillage is lab imagery, so push towards
    # variable framing, lighting, blur and orientation seen in farmer photos.
    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(s, scale=(0.5, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomVerticalFlip(),
        transforms.RandomRotation(25),
        transforms.ColorJitter(0.35, 0.35, 0.3, 0.04),
        transforms.RandomApply([transforms.GaussianBlur(5, (0.1, 2.0))], p=0.3),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    eval_tf = transforms.Compose([
        transforms.Resize(int(s * 1.14)),
        transforms.CenterCrop(s),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    dl = lambda items, tf, sh: DataLoader(ListDataset(items, tf), batch_size=args.batch_size,
                                          shuffle=sh, num_workers=args.workers)
    train_dl, val_dl, test_dl = dl(tr, train_tf, True), dl(va, eval_tf, False), dl(te, eval_tf, False)

    model = build_model(args.arch, len(labels), args.pretrained_path, args.pretrained_hub)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.02)
    steps = args.epochs * len(train_dl)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=args.lr, total_steps=steps, pct_start=0.15)
    loss_fn = nn.CrossEntropyLoss(label_smoothing=0.1)

    args.out.mkdir(parents=True, exist_ok=True)
    best = -1.0
    for ep in range(args.epochs):
        model.train()
        t0, run, n = time.time(), 0.0, 0
        for x, y in train_dl:
            opt.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            opt.step()
            sched.step()
            run += loss.item() * len(y)
            n += len(y)
        acc, _ = evaluate(model, val_dl, len(labels))
        print(f"epoch {ep + 1}/{args.epochs} loss {run / n:.3f} val_acc {acc:.3f} ({time.time() - t0:.0f}s)", flush=True)
        if acc > best:
            best = acc
            torch.save({"arch": args.arch, "img_size": s, "labels": labels,
                        "mean": IMAGENET_MEAN, "std": IMAGENET_STD,
                        "state_dict": model.state_dict()}, args.out / "classifier.pt")

    ckpt = torch.load(args.out / "classifier.pt", map_location="cpu")
    model.load_state_dict(ckpt["state_dict"])
    test_acc, cm = evaluate(model, test_dl, len(labels))
    per_cls = {labels[i]: (cm[i][i] / max(sum(cm[i]), 1)) for i in range(len(labels))}
    metrics = {"arch": args.arch, "img_size": s, "best_val_acc": best, "test_acc": test_acc,
               "per_class_test_acc": per_cls, "labels": labels, "confusion_matrix": cm,
               "n_train": len(tr), "n_val": len(va), "n_test": len(te)}
    (args.out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    (args.out / "labels.json").write_text(json.dumps(labels, indent=2))
    print(f"test_acc {test_acc:.3f}")


if __name__ == "__main__":
    main()
