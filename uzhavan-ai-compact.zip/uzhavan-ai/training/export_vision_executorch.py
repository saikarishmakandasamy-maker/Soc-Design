#!/usr/bin/env python3
"""Export the trained classifier to an ExecuTorch .pte (XNNPACK delegate).

  python training/export_vision_executorch.py --ckpt models/vision/classifier.pt
  python training/export_vision_executorch.py --ckpt models/vision/classifier.pt --int8 \
      --calib-dir datasets/PlantVillage/raw/color

Writes models/vision/crop_classifier_xnnpack[_int8].pte and verifies the .pte
against eager PyTorch on sample images (top-1 agreement, max |Δlogit|, latency).
"""
from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path

import numpy as np
import timm
import torch
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.vision.base import to_nchw_float  # noqa: E402  (same preprocessing as the app)


def load_model(ckpt_path: Path):
    ck = torch.load(ckpt_path, map_location="cpu")
    m = timm.create_model(ck["arch"], pretrained=False, num_classes=len(ck["labels"]))
    m.load_state_dict(ck["state_dict"])
    return m.eval(), ck


def sample_images(root: Path | None, n: int, seed=0):
    if not root:
        return []
    paths = [p for p in root.rglob("*") if p.suffix.lower() in {".jpg", ".jpeg", ".png"}]
    random.Random(seed).shuffle(paths)
    return paths[:n]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=Path, default=Path("models/vision/classifier.pt"))
    ap.add_argument("--out-dir", type=Path, default=Path("models/vision"))
    ap.add_argument("--int8", action="store_true", help="PT2E int8 static quantisation for XNNPACK")
    ap.add_argument("--calib-dir", type=Path, default=None, help="images for calibration / verification")
    ap.add_argument("--calib-n", type=int, default=64)
    ap.add_argument("--verify-n", type=int, default=48)
    args = ap.parse_args()

    from executorch.backends.xnnpack.partition.xnnpack_partitioner import XnnpackPartitioner
    from executorch.exir import to_edge_transform_and_lower

    model, ck = load_model(args.ckpt)
    size = ck["img_size"]
    example = (torch.randn(1, 3, size, size),)
    imgs = sample_images(args.calib_dir, max(args.calib_n, args.verify_n))
    tensors = [torch.from_numpy(to_nchw_float(Image.open(p), size)) for p in imgs]

    if args.int8:
        from executorch.backends.xnnpack.quantizer.xnnpack_quantizer import (
            XNNPACKQuantizer, get_symmetric_quantization_config)
        from torchao.quantization.pt2e.quantize_pt2e import convert_pt2e, prepare_pt2e
        if not tensors:
            raise SystemExit("--int8 needs --calib-dir with images")
        gm = torch.export.export(model, example).module()
        q = XNNPACKQuantizer().set_global(get_symmetric_quantization_config(is_per_channel=True))
        gm = prepare_pt2e(gm, q)
        with torch.no_grad():
            for x in tensors[: args.calib_n]:
                gm(x)
        export_model = convert_pt2e(gm)
        name = "crop_classifier_xnnpack_int8.pte"
    else:
        export_model = model
        name = "crop_classifier_xnnpack.pte"

    t0 = time.time()
    ep = torch.export.export(export_model, example)
    prog = to_edge_transform_and_lower(ep, partitioner=[XnnpackPartitioner()]).to_executorch()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    out = args.out_dir / name
    out.write_bytes(prog.buffer)
    print(f"wrote {out} ({out.stat().st_size / 1e6:.1f} MB) in {time.time() - t0:.0f}s")
    (args.out_dir / "labels.json").write_text(json.dumps(ck["labels"], indent=2))

    # ---- verify .pte against eager model
    from executorch.runtime import Runtime
    method = Runtime.get().load_program(str(out)).load_method("forward")
    agree, max_diff, lat = 0, 0.0, []
    vt = tensors[: args.verify_n] or [torch.randn(1, 3, size, size) for _ in range(8)]
    with torch.no_grad():
        for x in vt:
            ref = model(x)
            t1 = time.perf_counter()
            got = method.execute([x])[0]
            lat.append((time.perf_counter() - t1) * 1000)
            agree += int(ref.argmax() == got.argmax())
            max_diff = max(max_diff, float((ref - got).abs().max()))
    report = {"pte": name, "size_mb": round(out.stat().st_size / 1e6, 2), "img_size": size,
              "top1_agreement_vs_eager": agree / len(vt), "max_abs_logit_diff": round(max_diff, 4),
              "median_latency_ms_this_host": round(float(np.median(lat)), 1), "n": len(vt)}
    (args.out_dir / f"export_report{'_int8' if args.int8 else ''}.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
