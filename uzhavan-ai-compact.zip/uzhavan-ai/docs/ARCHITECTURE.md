# Architecture

## Two separate inference pipelines

The brief requires that, when a Hailo accelerator is used, the vision and LLM pipelines are documented separately.

```mermaid
flowchart LR
  subgraph IN[Input]
    CAM[Phone / Pi camera photo]
    MIC[Voice question - optional]
  end
  subgraph VISION["Pipeline A — Vision"]
    Q[Quality check<br/>OpenCV: blur, light, leaf size]
    direction TB
    VA["ExecuTorch runtime<br/>XNNPACK delegate<br/>Arm Cortex-A76 CPU<br/>crop_classifier_xnnpack_int8.pte"]
    VB["HailoRT<br/>Hailo-8/8L/10H NPU over PCIe<br/>crop_classifier.hef"]
    SEV[Severity<br/>OpenCV lesion area + overlay]
  end
  subgraph KNOW[Grounding]
    KB[(knowledge_base.json<br/>actions, doses, en/hi/ta)]
    REG[(regions.json<br/>zones, seasonal risks)]
    FACTS[FACTS block]
  end
  subgraph LLM["Pipeline B — Advisory LLM (always Arm CPU)"]
    LL["Llama 3.2 1B Instruct<br/>ExecuTorch .pte, 8da4w / SpinQuant<br/>XNNPACK + KleidiAI kernels<br/>TextLLMRunner (in-process) or llama_main"]
    G[Guard<br/>chemicals ⊆ facts, numbers ⊆ facts, script]
    MT[IndicTrans2 offline MT<br/>Tamil and other Indic languages]
    TPL[Template fallback]
  end
  OUT[Advice card + explanation + voice]
  CAM --> Q --> VA & VB --> SEV --> FACTS
  KB --> FACTS
  REG --> FACTS
  FACTS --> LL --> G
  G -- ok --> MT --> OUT
  G -- rejected --> TPL --> OUT
  MIC -->|faster-whisper / Vosk| LL
```

| | Pipeline A: vision | Pipeline B: advisory LLM |
|---|---|---|
| Model | MobileNetV3-Large (timm), 12 classes, 224×224 | Llama 3.2 1B Instruct (optionally LoRA fine-tuned) |
| Format | `.pte` (ExecuTorch), or `.hef` (Hailo) | `.pte` (ExecuTorch) |
| Runtime | `executorch.runtime` + XNNPACK, **or** HailoRT `InferVStreams` | `executorch.extension.llm.runner.TextLLMRunner`, or `llama_main` |
| Hardware | Arm CPU, **or** Hailo NPU | **Arm CPU only** (the brief's requirement) |
| Quantisation | int8 PT2E (XNNPACKQuantizer); Hailo DFC int8 | 8da4w groupwise (PTQ) or Meta SpinQuant |
| Code | `app/vision/executorch_backend.py`, `app/vision/hailo_backend.py` | `app/llm/runner.py`, `app/llm/prompt.py`, `app/llm/guard.py` |
| Export | `training/export_vision_executorch.py`, `training/export_onnx_for_hailo.py` + `docs/HAILO.md` | `training/export_llama.sh` |
| Switch | `vision.backend: executorch \| hailo` | `llm.mode: auto \| python \| binary` |

The two pipelines share nothing but the FACTS dictionary. Vision finishes in milliseconds, and Llama then gets the whole CPU. On an AI HAT+ 2, the Hailo-10H could also run an LLM, but the brief requires Llama on ExecuTorch, so the NPU is used for vision only.

## Request flow (`app/pipeline.py`)

1. EXIF-rotate the photo; run the quality check (Laplacian variance, brightness, leaf coverage).
2. Vision → top-k. If the farmer picked a crop, other crops' classes are masked out and the probabilities renormalised.
3. Confidence below `vision.confidence_threshold` → *uncertain* path: no actions, "retake photo / ask officer", top-3 shown.
4. Severity: leaf mask (plant colour, minus a uniform background seen at the border, then GrabCut, then shadow trim, then filled outline) → lesion share → none / mild / moderate / severe. The farmer can override.
5. The knowledge base selects actions allowed at that severity (`severity_policy`, `min_severity`).
6. Region: district → zone → seasonal notes for this month; `elevated_risk` if this condition is in a current rule.
7. FACTS → Llama prompt (Llama 3 chat template; facts in Hindi when Hindi is the output language).
8. The guard checks the answer. If it fails, the template is used, and the rejected text is kept for the debug panel.
9. Tamil: Llama writes English → IndicTrans2 with doses swapped for placeholders, or the English explanation is shown under the Tamil card.
10. The result is stored in local SQLite (`data/history.db`) for follow-up chat and village-level review.

## Offline guarantees

- The UI loads nothing from the internet: no CDNs, web fonts or analytics.
- All models load from local paths (`local_files_only=True` for the MT model).
- The phone ↔ Pi link is the Pi's own hotspot. No data leaves the device.
