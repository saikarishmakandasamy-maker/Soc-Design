# Uzhavan AI — offline crop doctor for farmers (Llama 3.2 + ExecuTorch)

*Uzhavan* (உழவன்) means "farmer" in Tamil.

A farmer photographs a leaf. **With no internet connection**, Uzhavan AI identifies the disease or pest, grades how severe it is, gives treatment steps chosen to match that severity, adds advice for the farmer's district and season, and explains everything in **English, Hindi or Tamil**. The explanation and follow-up chat come from **Llama 3.2 1B Instruct running on-device through ExecuTorch**.

| | |
|---|---|
| 🎥 **Demo video** | _add your YouTube / Drive link here_ |
| 📄 **Final report** | [`docs/Uzhavan_AI_Final_Report.pdf`](docs/Uzhavan_AI_Final_Report.pdf) |
| 👥 **Team** | Hari Babu M — Madras Institute of Technology, Anna University, Chennai _(add team members / mentor)_ |


> **About this repository.** The key source files are shown below so they can be read directly on GitHub. The **complete runnable project** (69 files, including the trained vision model, web UI, tests, sample photos and setup scripts) is in [`uzhavan-ai-full-source.zip`](uzhavan-ai-full-source.zip). Download it, unzip, and follow "Run it" below.

---

## How the brief's requirements are met

| Requirement | How Uzhavan AI does it | Where in the code |
|---|---|---|
| Detect diseases and pests | MobileNetV3-Large classifier, **24 classes** on 5 crops, plus a "not in my list" class | `app/vision/`, `training/train_classifier.py` |
| Classify severity | OpenCV lesion-area estimate (none / mild / moderate / severe) with a visible overlay; the farmer can override it | `app/severity.py` |
| Recommend treatment | Vetted knowledge base, actions selected by severity (mild → no chemicals) | `data/knowledge_base.json`, `app/knowledge/kb.py` |
| Region-specific advice | 7 Tamil Nadu agro-climatic zones, district lookup, seasonal risk rules | `data/regions.json`, `app/knowledge/regions.py` |
| Multiple local languages | Full UI, advice, symptoms and safety text in **English, हिंदी, தமிழ்**; voice output | `app/i18n/`, `app/speech/` |
| Works offline | Every model runs locally; the UI uses no CDNs; phones connect over the device's own hotspot | `app/main.py`, `scripts/setup_pi.sh` |
| **Llama, deployed with ExecuTorch** | **Llama 3.2 1B Instruct → `.pte` (8da4w, XNNPACK, 2048 context)**, run in-process with `TextLLMRunner` | `training/export_llama_colab.ipynb`, `app/llm/runner.py` |
| Arm platforms | Both models are ExecuTorch **XNNPACK** builds (Arm-optimised kernels); a Raspberry Pi 5 setup script is included; Hailo NPU vision backend for AI HAT+ | `scripts/setup_pi.sh`, `app/vision/hailo_backend.py`, `docs/HAILO.md` |

## Architecture

```
photo ─► quality check ─► vision (ExecuTorch-XNNPACK │ HailoRT NPU) ─► severity (OpenCV)
      ─► knowledge base + region rules ─► FACTS ─► Llama 3.2 1B (ExecuTorch, CPU)
      ─► guard (no unlisted chemical / number / role-flip / wrong script) ─► advice card + explanation + chat
```

- **The LLM never decides treatment.** Doses come only from the knowledge base. Llama explains the facts it is given, and an output **guard** rejects any answer that names an unlisted chemical, contains a number not in the facts, talks as if it were the farmer, or is in the wrong script.
- **The card comes first.** Diagnosis and advice appear in under a second, and Llama's explanation fills in when ready, so a slow CPU never blocks the farmer.
- **Common questions** ("how much do I mix?", "why did this happen?", "is it safe to eat?") are answered straight from the card in all three languages. Open questions go to Llama.
- **Honest uncertainty.** Below 60 % confidence the app says "not sure" and shows its top guesses as buttons for the farmer to confirm. Photos of crops it doesn't cover get "🚫 Not in my list".

Details: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Results

| Metric | Value |
|---|---|
| Vision test accuracy (516 held-out images, 24 classes) | **98.4 %** |
| ExecuTorch `.pte` vs PyTorch | fp32 100 % top-1 agreement · **int8 99.0 %, 4.5 MB** (3.7× smaller) |
| Unseen crops (peach, strawberry; 44 photos) handled safely | **91 %** (the earlier 12-class model managed 68 %) |
| Vision latency, int8 (2-core x86 dev host) | **3.1 ms** median per image |
| Severity estimation (OpenCV) | 76 ms median |
| Llama 3.2 1B on a 2-core x86 laptop (WSL2, 2 threads) | ~3 tokens/s decode; the card-first design keeps the app responsive |
| Automated tests | **32 passing** |

Real screenshots from the team laptop: `docs/screenshots/` (inside the full-source zip) (Llama loading through ExecuTorch, a Llama explanation, and the Tamil result screen).

**Crops and classes:**
- **Tomato (10):** bacterial spot, early blight, late blight, leaf mould, septoria, target spot, spider mites, yellow leaf curl virus, mosaic virus, healthy
- **Potato (3)** and **Maize (4):** blights, rust, gray leaf spot, healthy
- **Capsicum/chilli (2)** and **Grape (4):** bacterial spot, black rot, esca, leaf blight, healthy

## Run it

**Laptop (Linux, macOS, or Windows with WSL2), Python 3.10–3.13.** Unzip `uzhavan-ai-full-source.zip`, open the `uzhavan-ai` folder, then:
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.main            # open http://localhost:8080 and try images from samples/
pytest -q                     # 32 tests
```

**Add Llama 3.2 1B.** The model file is 822 MB, too large for GitHub. Accept the licence at huggingface.co/meta-llama/Llama-3.2-1B-Instruct, then open [`training/export_llama_colab.ipynb`](training/export_llama_colab.ipynb) in Google Colab (free, CPU only). It downloads the model, exports it to ExecuTorch, and tests it. Copy `llama3_2_1b_instruct_8da4w.pte` and `tokenizer.model` into `models/llm/` and restart the app; the badge turns green: **"Llama 3.2 · ExecuTorch ✓"**.

**Raspberry Pi 5 / Arm64 Linux:** `WITH_HOTSPOT=1 bash scripts/setup_pi.sh`, then `./scripts/run.sh`. Phones join the "Uzhavan-AI" Wi-Fi and open `http://10.42.0.1:8080`. With an AI HAT+, set `vision.backend: hailo` (see `docs/HAILO.md` in the full-source zip). Vision then runs on the NPU via HailoRT, while Llama stays on the Arm CPU via ExecuTorch.

## Repository layout

| File | What it is |
|---|---|
| `uzhavan-ai-full-source.zip` | **Complete project** (all code, trained int8 vision model, UI, tests, samples, scripts) |
| `app/pipeline.py` | End-to-end pipeline: quality check, vision, severity, advice, region, Llama explanation |
| `app/vision/executorch_backend.py` | Vision inference with the ExecuTorch runtime (XNNPACK) |
| `app/llm/runner.py` | Llama 3.2 on ExecuTorch (`TextLLMRunner`, custom ops, thread pool) |
| `app/llm/prompt.py` | Grounded Llama 3 chat prompts |
| `app/llm/guard.py` | Output guard: no unlisted chemical or number, no role-flip, correct script |
| `app/severity.py` | OpenCV severity estimation and overlay |
| `app/main.py` | Offline web server and API |
| `data/knowledge_base.json` | Advice for 32 conditions in English, Hindi and Tamil |
| `training/train_classifier.py` | Vision model training |
| `training/export_vision_executorch.py` | Export to ExecuTorch `.pte` (fp32 / int8) with verification |
| `training/export_llama_colab.ipynb` | Exports Llama 3.2 1B Instruct to ExecuTorch in Google Colab |
| `docs/ARCHITECTURE.md` | Architecture and the two inference pipelines |
| `docs/Uzhavan_AI_Final_Report.pdf` | Final project report |

## Safety and limitations

- ⚠ **The spray doses are prototype data**, marked `"verified": false`. They must be checked against the TNAU Agritech portal / ICAR package of practices and the CIB&RC product label before any field use. The app shows this warning next to every spray.
- The vision model is trained on PlantVillage (lab images of single leaves). Accuracy on real field photos will be lower. Asking the farmer to pick the crop, the "not sure" path, and confirming the closest match are there to compensate.
- Severity is a colour heuristic, so the farmer can override it.
- Rice and the 5 pests have knowledge-base entries but no training data yet. The next step is adding a rice dataset and IP102 pest images.
- Llama 3.2 does not officially support Tamil. Tamil users get the full Tamil card, and the explanation can be translated with an optional offline IndicTrans2 model.

## Credits and licence

- Code: MIT licence (see `LICENSE`).
- **Llama 3.2** is used under the [Llama 3.2 Community License](https://www.llama.com/llama3_2/license/), "Built with Llama". Model weights are not redistributed here.
- Training images: [PlantVillage dataset](https://github.com/spMohanty/PlantVillage-Dataset) (Hughes & Salathé, 2015); see that repository for its terms.
- Built with [ExecuTorch](https://github.com/pytorch/executorch), PyTorch, timm, OpenCV and FastAPI.
